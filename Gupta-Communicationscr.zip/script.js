function Function() {
	
var welcoming="Hello user, welcome to the world of electronics. This is the India's best electronical shop.";
alert(welcoming);
var cookies="To buy things, you have to give us some of your cookies. This information will be surely private but you can preview our products without giving any of the cookies.";
alert(cookies);
	
	var name= prompt("What's your name?", "[Your Name]");
	var bg= prompt("What's your favourite color?", "[Any Color]")
	var msg;
	var day;
	var hour;
	var day= new Date;
	var Hour=day.getHours();

	
	
	if (Hour<12) {
		msg="Hello "+name+", "+"good morning!";
		document.getElementById("namesec").innerHTML=msg;
}
	else if (Hour>12 && Hour<16) {
		msg="Hello "+name+", "+"good afternoon!";
		document.getElementById("namesec").innerHTML=msg;
}

else if (Hour>=16 && Hour<23) {
		msg="Hello "+name+", "+"good evening!";
		document.getElementById("namesec").innerHTML=msg;
}

else if(Hour>23 && Hour>24){
	msg="Hello "+name+", "+"It's night, greetings of the day!";
	document.getElementById("namesec").innerHTML=msg;
}
document.body.style.backgroundColor=bg;
}
